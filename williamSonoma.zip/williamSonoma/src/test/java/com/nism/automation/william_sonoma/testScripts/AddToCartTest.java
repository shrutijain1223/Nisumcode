package com.nism.automation.william_sonoma.testScripts;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.nism.automation.william_sonoma.TestBase.TestBase;
import com.nism.automation.william_sonoma.pages.CheckoutPage;
import com.nism.automation.william_sonoma.pages.HomePage;
import com.nism.automation.william_sonoma.pages.ProductListPage;
import com.nism.automation.william_sonoma.pages.ProductPage;
import com.nism.automation.william_sonoma.pages.ShoppingCartPage;

public class AddToCartTest extends TestBase{

	@BeforeMethod
	public void setup(){
		init();	
		openApplication();
	}
	
	@Test
	public void addToCart(){
		HomePage homePage = new HomePage();
		ProductPage productPage = new ProductPage();
		CheckoutPage checkoutPage = new CheckoutPage();
		ShoppingCartPage shoppingCartPage = new ShoppingCartPage();
		homePage.moveToCookware();
		homePage.clickOnTeaKettles();
		ProductListPage productListPage = new ProductListPage();
		productListPage.selectProduct();
		productPage.clickOnAddToCart();
		checkoutPage.clickOnCheckout();
		shoppingCartPage.clickOnSaveForLater();
		Assert.assertTrue(shoppingCartPage.verifySaveForLaterMessage());
	}
	
	@AfterMethod
	public void tearDown(){
		driver.close();
	}
}
