package com.nism.automation.william_sonoma.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.nism.automation.william_sonoma.TestBase.TestBase;

public class ProductPage extends TestBase{
	//button[@id='primaryGroup_addToCart_0']/span
	
	
	@FindBy(xpath="//span[text()='Add to Cart']")
	public WebElement btnAddToCart;
	
	
	public ProductPage(){
		PageFactory.initElements(driver, this);
	}
	
	public void clickOnAddToCart(){
		scrollToElement(btnAddToCart);
		clickOnElementUsingJavascript(btnAddToCart);
	}
}
