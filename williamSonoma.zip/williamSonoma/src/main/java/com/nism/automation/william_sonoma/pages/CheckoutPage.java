package com.nism.automation.william_sonoma.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.nism.automation.william_sonoma.TestBase.TestBase;

public class CheckoutPage extends TestBase{

	@FindBy(xpath="//a[@title='Checkout']")
	public WebElement btnCheckout;
	
	public CheckoutPage(){
		PageFactory.initElements(driver, this);
	}
	
	public void clickOnCheckout(){
		clickOnElementUsingJavascript(btnCheckout);
	}
}
