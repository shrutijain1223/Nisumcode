package com.nism.automation.william_sonoma.util;

public class Constants {

	public static final String WILLIAM_SONOMA_URL = "http://www.williams-sonoma.com/";
	public static final long PAGE_LOAD_TIMEOUT = 100;
	public static final long IMPLICIT_WAIT = 100;
	public static final String BROWSER = "chrome";
}
