package com.nism.automation.william_sonoma.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.nism.automation.william_sonoma.TestBase.TestBase;

public class HomePage extends TestBase{

	@FindBy(linkText="Cookware")
	public WebElement tabCookware;
	
	@FindBy(linkText="Tea Kettles")
	public WebElement linkTeaKettles;

	public HomePage(){
		PageFactory.initElements(driver, this);
	}
	
	public void moveToCookware(){
		WebDriverWait wait = new WebDriverWait(driver, 1000);
		wait.until(ExpectedConditions.visibilityOf(tabCookware));
		Actions action = new Actions(driver);
		action.moveToElement(tabCookware).build().perform();
	}
	
	public void clickOnTeaKettles(){
		clickOnElementUsingJavascript(linkTeaKettles);
	}
	
}
