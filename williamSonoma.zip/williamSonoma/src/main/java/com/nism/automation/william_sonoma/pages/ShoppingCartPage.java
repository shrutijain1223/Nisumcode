package com.nism.automation.william_sonoma.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.nism.automation.william_sonoma.TestBase.TestBase;

public class ShoppingCartPage extends TestBase{

	@FindBy(xpath="//a[text()='Save For Later']")
	public WebElement linkSaveForLater;
	
	@FindBy(xpath="//p[@class='save-for-later-message']//a")
	public WebElement textSaveForLater;
	
	public ShoppingCartPage(){
		PageFactory.initElements(driver, this);
	}
	
	public void clickOnSaveForLater(){
		clickOnElementUsingJavascript(linkSaveForLater);
	}
	
	public boolean verifySaveForLaterMessage(){
		if(textSaveForLater.getText().contains("saved item")){
			return true;
		}
		else{
			return false;
		}
	}
}
